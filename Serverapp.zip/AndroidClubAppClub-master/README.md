# AndroidClubAppClub
This application fetches data from the server and displays it.
The data that is fetched from server depends on the user id and MAC address of the user.
