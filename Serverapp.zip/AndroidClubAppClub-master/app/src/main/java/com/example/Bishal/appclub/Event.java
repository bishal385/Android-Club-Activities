package com.example.Bishal.appclub;

/**
 * Created by Rohaan on 12-Dec-17.
 */

public class Event {

    public final String title;


    public Event(String title) {
        this.title = title;
    }
}
